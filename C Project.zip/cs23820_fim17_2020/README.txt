Files:
assignment.zip contains source code for program

build_and_run.mkv is a screencast demonstrating that the program builds and runs

protection_and_structure.mkv is a screencast showing how the program is protected from invalid inputs and
overviewing some of the data structures used

report.pdf is the report discussing what I did along with some justifications

Code information:
The code is written in C11 and all header and source code files should be in the same directory alongside
CMakeLists.txt for building, with all other files (e.g. .txt files) in the cmake-build-debug directory

Standard libraries used:
stdio.h
stdlib.h
string.h
math.h