#imports sqrt function from the math module
from math import sqrt

#class that handles the A* algorithm and performs the main computation of the program
class aStar():
  #initialisation procedure that initialises all class attributes
  def __init__(self, importGraph, importCoordinates):
    self.graph = importGraph
    self.coordinates = importCoordinates
    self.startNode = ""
    self.destinationNode = ""
    self.path = []
    self.walkSpeed = 1.4
    self.runSpeed = 2.5
    self.pixelsToMetres = 3.846

  #procedure that takes start and destination node as parameters and stores them as the attributes startNode and destinationNode
  def importValues(self, importStartNode, importDestinationNode):
    self.startNode = importStartNode
    self.destinationNode = importDestinationNode

  #function that calculates and returns the quickest route between two nodes on the graph
  def calculateRoute(self):
    #initialises openList, closedList and dictionary nodes
    openList = [self.startNode]
    closedList = []
    nodes = {}
    #stores attribute startNode in dictionary nodes with its calculated f cost and no parent
    g = 0
    h = self.calculateh(self.startNode)
    f = g + h
    nodes[self.startNode] = {'f':f, 'parent':None}
    #while loop that continues as long as there are still unexplored nodes that can be reached
    while len(openList) > 0:
      #finds the node in openList with lowest f cost and stores it as string currentNode
      currentNode = openList[0]
      for node in openList:
        if nodes[node]['f'] < nodes[currentNode]['f']:
          currentNode = node
      #if string currentNode is attribute destinationNode calls buildPath method and returns attribute path
      if currentNode == self.destinationNode:
        self.buildPath(nodes, currentNode)
        return self.path
      #removes string currentNode from openList and appends it to closedList
      openList.remove(currentNode)
      closedList.append(currentNode)
      #for loop that finds all of string currentNodes neighbours
      for neighbour in self.findNeighbours(currentNode):
        #if string neighbour has not already been activated add it to dictionary nodes
        if neighbour not in closedList:
          #stores string neighbour in dictionary nodes with its calculated f cost and string currentNode as its parent
          nodes[neighbour] = {'f':0, 'parent':currentNode}
          g = self.calculateg(nodes, neighbour)
          h = self.calculateh(neighbour)
          f = g + h
          nodes[neighbour]['f'] = f
          #if string neighbour not already discovered append it to openList
          if neighbour not in openList:
            openList.append(neighbour)
        #if string neighbour has already been activated check if string currentNode has lower f cost than its parent
        else:
          #calculates the g costs of string currentNode and string currentParent
          currentg = self.calculateg(nodes, currentNode)
          currentParent = nodes[currentNode]['parent']
          nodes[currentNode]['parent'] = neighbour
          altg = self.calculateg(nodes, currentNode)
          #if string currentNode has g cost less than string currentParent set string currentNode as new parent
          if altg > currentg:
            nodes[currentNode]['parent'] = currentParent

  #function that calculates and returns the g cost of a node
  def calculateg(self, nodes, node):
    g = 0
    #while loop that continues until string node is attribute startNode
    while node != self.startNode:
      #finds weight between string node and its parent using attribute graph and adds it to integer g
      g += self.graph[node][nodes[node]['parent']]
      #sets string node to previous nodes parent
      node = nodes[node]['parent']
    return g

  #function that calculates and returns the h cost of a node
  def calculateh(self, node):
    #uses attribute coordinates to calculate integers xDist and yDist and squares them
    xDist = (self.coordinates[self.destinationNode][0] - self.coordinates[node][0]) ** 2
    yDist = (self.coordinates[self.destinationNode][1] - self.coordinates[node][1]) ** 2
    #uses Pythagoras to calculate float h
    h = sqrt(xDist + yDist)
    return h

  #function that finds and returns all of a nodes neighbours
  def findNeighbours(self, node):
    neighbours = []
    #for loop that appends all of the neighbours of string node to list neighbours
    for neighbour in self.graph[node]:
      neighbours.append(neighbour)
    return neighbours

  #procedure that stores the most efficient route as attribute path
  def buildPath(self, nodes, node):
    self.path = [node]
    #while loop that sets string node to the previous nodes parent and appends it to attribute path
    while nodes[node]['parent'] != None:
      node = nodes[node]['parent']
      self.path.append(node)

  #function that calculates and returns the estimated time taken to complete the route in real life
  def calculateTimeTaken(self):
    routeLength = 0
    #for loop that adds the weight of every edge in attribute path to integer routeLength
    for index in range(len(self.path) - 1):
      routeLength += self.graph[self.path[index]][self.path[index + 1]]
    walkTime = routeLength / (self.walkSpeed * self.pixelsToMetres)
    runTime = routeLength / (self.runSpeed * self.pixelsToMetres)
    return walkTime, runTime
