#imports everything used from the tkinter and the interface_class modules
from tkinter import *
from interface_class import *

#function that takes contents of file as parameter and returns the rooms list
def createRooms(file):
    try:
        rooms = []
        dataPresent = False
        for line in file:
            room = line.strip('\n')
            rooms.append(room)
            if len(line) > 0:
                dataPresent = True
        if dataPresent == False:
            displayError('rooms', 'corrupted')
        return rooms
    except:
        displayError('rooms', 'corrupted')

#function that takes contents of file as parameter and returns the instructions string
def createInstructions(file):
    try:
        instructions = ""
        dataPresent = False
        for line in file:
            instructions += line
            if len(line) > 0:
                dataPresent = True
        if dataPresent == False:
            displayError('instructions', 'corrupted')
        return instructions
    except:
        displayError('instructions', 'corrupted')

#function that takes contents of file as parameter and returns the graph dictionary
def createGraph(file):
    try:
        graph = dict()
        tempString = ''
        lineNo = 1
        dataPresent = False
        for line in file:
            graph[str(lineNo)] = {}
            for character in line:
                if character == ',':
                    graph[str(lineNo)][key] = int(tempString)
                    tempString = ''
                elif character == ':':
                    key = tempString
                    tempString = ''
                else:
                    tempString += character
            graph[str(lineNo)][key] = int(tempString)
            tempString = ''
            lineNo += 1
            if len(line) > 0:
                dataPresent = True
        if dataPresent == False:
            displayError('graph', 'corrupted')
        return graph
    except:
        displayError('graph', 'corrupted')

#function that takes contents of file as parameter and returns the coordinates dictionary
def createCoordinates(file):
    try:
        coordinates = dict()
        tempString = ''
        lineNo = 1
        dataPresent = False
        for line in file:
            coordinates[str(lineNo)] = []
            for character in line:
                if character == ',':
                    coordinates[str(lineNo)].append(int(tempString))
                    tempString = ''
                else:
                    tempString += character
            coordinates[str(lineNo)].append(int(tempString))
            tempString = ''
            lineNo += 1
            if len(line) > 0:
                dataPresent = True
        if dataPresent == False:
            displayError('coordinates', 'corrupted')
        return coordinates
    except:
        displayError('coordinates', 'corrupted')

#function that takes contents of file as parameter and returns the nodes dictionary
def createNodes(file):
    try:
        nodes = dict()
        tempString = ''
        dataPresent = False
        for line in file:
            for character in line:
                if character == ',':
                    nodes[key].append(tempString)
                    tempString = ''
                elif character == ':':
                    key = tempString
                    nodes[key] = []
                    tempString = ''
                else:
                    tempString += character
            nodes[key].append(tempString.strip('\n'))
            tempString = ''
            if len(line) > 0:
                dataPresent = True
        if dataPresent == False:
            displayError('nodes', 'corrupted')
        return nodes
    except:
        displayError('nodes', 'corrupted')

#procedure that generates and displays a window showing an error message
def displayError(fileName, errorType):
        root = Tk()
        errorFrame = Frame(root)
        errorLabel = Label(errorFrame)
        if errorType == 'missing':
            errorLabel.configure(text = (fileName + " file is missing"))
        elif errorType == 'corrupted':
            errorLabel.configure(text = (fileName + " file is corrupted"))
        errorFrame.pack()
        errorLabel.pack(side = TOP, padx = 50, pady = 50)
        root.mainloop()
        quit()

if __name__ == "__main__":
    #opens rooms.txt file in read mode as file
    try:
        with open('rooms.txt', 'r') as file:
            #calls createRooms function with file as parameter and returns to rooms
            rooms = createRooms(file)
    except:
        displayError('rooms', 'missing')

    #opens instructions.txt file in read mode as file
    try:
        with open('instructions.txt', 'r') as file:
            #calls createInstructions function with file as parameter and returns to instructions
            instructions = createInstructions(file)
    except:
        displayError('instructions', 'missing')

    #opens graph.txt file in read mode as file
    try:
        with open('graph.txt', 'r') as file:
            #calls createGraph function with file as parameter and returns to graph
            graph = createGraph(file)
    except:
        displayError('graph', 'missing')

    #opens coordinates.txt file in read mode as file
    try:
        with open('coordinates.txt', 'r') as file:
            #calls createCoordinates function with file as parameter and returns to coordinates
            coordinates = createCoordinates(file)
    except:
        displayError('coordinates', 'missing')

    #opens nodes.txt file in read mode as file
    try:
        with open('nodes.txt', 'r') as file:
            #calls createNodes function with file as parameter and returns to nodes
            nodes = createNodes(file)
    except:
        displayError('nodes', 'missing')

    #creates GUI object from interface class and initialises with rooms, instructions, graph, coordinates and nodes as parameters
    GUI = interface(rooms, instructions, graph, coordinates, nodes)
    #calls startScreen procedure from GUI object
    GUI.startScreen()
