#imports everything used from the tkinter and the aStar_class modules
from tkinter import *
from aStar_class import *

#class that handles the GUI
class interface():
    #initialisation procedure that initialises all class attributes and creates PathFinder object from aStar class with importGraph and importCoordinates as parameters
    def __init__(self, importRooms, importInstructions, importGraph, importCoordinates, importNodes):
        self.root = Tk()
        self.rooms = importRooms
        self.instructions = importInstructions
        self.coordinates = importCoordinates
        self.nodes = importNodes
        self.walkTimeString = StringVar()
        self.walkTimeString.set("Time it will take when walking: ")
        self.runTimeString = StringVar()
        self.runTimeString.set("Time it will take when running: ")
        self.errorString = StringVar()
        self.errorString.set("")
        self.lines = []
        self.circles = []
        self.PathFinder = aStar(importGraph, importCoordinates)

    #procedure that creates and displays the screen user will see when program is started
    def startScreen(self):
        #creates frame with blue background
        self.startScreenFrame = Frame(self.root)
        self.startScreenFrame.configure(bg = 'blue')
        #creates label with white text and blue background which reads "QES Pathfinding Program"
        self.titleLabel = Label(self.startScreenFrame)
        self.titleLabel.configure(text = "QES Pathfinding Program", fg = 'white', bg = 'blue')
        #creates button which reads "Start" and calls procedure nextScreen
        self.startButton = Button(self.startScreenFrame)
        self.startButton.configure(text = "Start", command = self.nextScreen)
        #packs the frame, label and button
        self.startScreenFrame.pack()
        self.titleLabel.pack(side = TOP, padx = 50, pady = (40, 10))
        self.startButton.pack(side = BOTTOM, pady = (10, 40))
        #starts the mainloop for the root window
        self.root.mainloop()

    #procedure that destroys the start screen and calls mainScreen procedure
    def nextScreen(self):
        self.startScreenFrame.destroy()
        self.mainScreen()

    #procedure that creates and displays the screen user will see when using program
    def mainScreen(self):
        #creates main frame with blue background
        self.mainScreenFrame = Frame(self.root)
        self.mainScreenFrame.configure(bg = 'blue')
        #calls procedures map and controlPanel
        self.map()
        self.controlPanel()
        #packs the main frame and both frames created in the called procedures
        self.mainScreenFrame.pack()
        self.mapFrame.pack(side = LEFT)
        self.controlPanelFrame.pack(side = RIGHT, padx = 100)

    #procedure that creates the map side of the screen
    def map(self):
        #creates frame
        self.mapFrame = Frame(self.mainScreenFrame)
        #creates canvas with a height and width of 600 pixels
        self.mapCanvas = Canvas(self.mapFrame, width = 600, height = 600)
        #imports the map and stores it as PhotoImage mapImage
        self.mapImage = PhotoImage(file = 'map.png')
        #places PhotoImage mapImage in the centre of the canvas
        self.mapCanvas.create_image(300, 300, image = self.mapImage)
        #packs the canvas
        self.mapCanvas.pack()

    #procedure that creates the control panel side of the screen
    def controlPanel(self):
        #creates frame with blue background
        self.controlPanelFrame = Frame(self.mainScreenFrame)
        self.controlPanelFrame.configure(bg = 'blue')
        #calls procedures startLocation and endLocation
        self.startLocation()
        self.endLocation()
        #creates label with white text and blue background which reads as the string stored in attribute walkTimeString
        self.walkTimeLabel = Label(self.controlPanelFrame)
        self.walkTimeLabel.configure(textvariable = self.walkTimeString, fg = 'white', bg = 'blue')
        #creates label with white text and blue background which reads as the string stored in attribute runTimeString
        self.runTimeLabel = Label(self.controlPanelFrame)
        self.runTimeLabel.configure(textvariable = self.runTimeString, fg = 'white', bg = 'blue')
        #creates label with white text and blue background which reads as the string stored in attribute instructions
        self.instructionsLabel = Label(self.controlPanelFrame)
        self.instructionsLabel.configure(text = self.instructions, fg = 'white', bg = 'blue')
        #creates button which reads "Calculate Route" and calls procedure runAStarAlgorithm
        self.calculateRouteButton = Button(self.controlPanelFrame)
        self.calculateRouteButton.configure(text = "Calculate Route", command = self.runAStarAlgorithm)
        #creates label with white text and blue background which reads as the string stored in attribute errorString
        self.errorLabel = Label(self.controlPanelFrame)
        self.errorLabel.configure(textvariable = self.errorString, fg = 'white', bg = 'blue')
        #packs both frames created in the called procedures, the four labels and the button
        self.startLocationFrame.pack(side = TOP)
        self.endLocationFrame.pack(side = TOP)
        self.walkTimeLabel.pack(side = TOP)
        self.runTimeLabel.pack(side = TOP)
        self.instructionsLabel.pack(side = TOP)
        self.calculateRouteButton.pack(side = TOP)
        self.errorLabel.pack(side = BOTTOM)

    #procedure that creates the frame where user enters their start location
    def startLocation(self):
        #creates frame with blue background
        self.startLocationFrame = Frame(self.controlPanelFrame)
        self.startLocationFrame.configure(bg = 'blue')
        #creates label with white text and blue background which reads "Where you are now:"
        self.startLocationLabel = Label(self.startLocationFrame)
        self.startLocationLabel.configure(text = "Where you are now:", fg = 'white', bg = 'blue')
        #initialises stringVar selectedStartLocation
        self.selectedStartLocation = StringVar()
        #creates option menu which displays stringVar selectedStartLocation, contains the contents of attribute rooms and calls procedure resetVariables when option selected
        self.startLocationMenu = OptionMenu(self.startLocationFrame, self.selectedStartLocation, *self.rooms, command = self.resetVariables)
        #packs the label and option menu
        self.startLocationLabel.pack(side = LEFT)
        self.startLocationMenu.pack(side = RIGHT)

    #procedure that creates the frame where user enters their end location
    def endLocation(self):
        #creates frame with blue background
        self.endLocationFrame = Frame(self.controlPanelFrame)
        self.endLocationFrame.configure(bg = 'blue')
        #creates label with white text and blue background which reads "Where you are going:"
        self.endLocationLabel = Label(self.endLocationFrame)
        self.endLocationLabel.configure(text = "Where you are going:", fg = 'white', bg = 'blue')
        #initialises stringVar selectedEndLocation
        self.selectedEndLocation = StringVar()
        #creates option menu which displays stringVar selectedEndLocation, contains the contents of attribute rooms and calls procedure resetVariables when option selected
        self.endLocationMenu = OptionMenu(self.endLocationFrame, self.selectedEndLocation, *self.rooms, command = self.resetVariables)
        #packs the label and option menu
        self.endLocationLabel.pack(side = LEFT)
        self.endLocationMenu.pack(side = RIGHT)

    #procedure that deletes all lines and circles on the canvas and sets walkTimeString and runTimeString to their initial values
    #has x as parameter because subroutines called from option menus require a parameter
    def resetVariables(self, x):
        for line in self.lines:
            self.mapCanvas.delete(line)
        for circle in self.circles:
            self.mapCanvas.delete(circle)
        self.walkTimeString.set("Time it will take when walking: ")
        self.runTimeString.set("Time it will take when running: ")
        self.errorString.set("")

    #procedure that calls the PathFinder object to calculate route and time taken
    def runAStarAlgorithm(self):
        #if stringVar selectedStartLocation and stringVar selectedEndLocation contain values which are not the same finds which node corresponds to the selected locations
        if self.selectedStartLocation.get() != "" and self.selectedEndLocation.get() != "" and self.selectedStartLocation.get() != self.selectedEndLocation.get():
            for node in self.nodes:
                if self.selectedStartLocation.get() in self.nodes[node]:
                    startNode = node
                if self.selectedEndLocation.get() in self.nodes[node]:
                    destinationNode = node
            if startNode != destinationNode:
                #imports nodes into PathFinder object
                self.PathFinder.importValues(startNode, destinationNode)
                #calls function calculateRoute from PathFinder object which returns to list path
                path = self.PathFinder.calculateRoute()
                #calls procedure displayRoute with list path as parameter
                self.displayRoute(path)
                #calls procedure calculateTimeTaken from PathFinder object which returns to integers walkTime and runTime
                walkTime, runTime = self.PathFinder.calculateTimeTaken()
                #updates stringVar walkTimeString and stringVar runTimeString with integers walkTime and runTime added to the end
                self.walkTimeString.set("Time it will take when walking: " + str(round(walkTime)) + "s")
                self.runTimeString.set("Time it will take when running: " + str(round(runTime)) + "s")
            else:
                self.errorString.set("Error: these rooms are too close together")
        else:
            self.errorString.set("Error: you cannot enter the same room")

    #procedure that displays the route on the canvas
    def displayRoute(self, path):
        #calls procedure resetVariables
        self.resetVariables('')
        #creates a line between each node in list path and a circle at each node in list path
        for index in range(len(path) - 1):
            self.lines.append(self.mapCanvas.create_line(self.coordinates[path[index]][0], self.coordinates[path[index]][1], self.coordinates[path[index + 1]][0], self.coordinates[path[index + 1]][1], fill = 'red', width = 5))
            self.circles.append(self.mapCanvas.create_oval(self.coordinates[path[index]][0] - 2, self.coordinates[path[index]][1] - 2, self.coordinates[path[index]][0] + 2, self.coordinates[path[index]][1] + 2, outline = 'red', fill = 'red'))
        #creates two larger circles at first and last node in list path
        self.circles.append(self.mapCanvas.create_oval(self.coordinates[path[0]][0] - 4, self.coordinates[path[0]][1] - 4, self.coordinates[path[0]][0] + 4, self.coordinates[path[0]][1] + 4, outline = 'red', fill = 'red'))
        self.circles.append(self.mapCanvas.create_oval(self.coordinates[path[len(path) - 1]][0] - 4, self.coordinates[path[len(path) - 1]][1] - 4, self.coordinates[path[len(path) - 1]][0] + 4, self.coordinates[path[len(path) - 1]][1] + 4, outline = 'red', fill = 'red'))
