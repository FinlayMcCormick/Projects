﻿using System.Collections.Generic;

namespace KanbanConsoleApp.Features.Tasks
{
    public class TaskRepository
    {
        private readonly List<Task> _tasks = new List<Task>();

        public void SaveTask(Task task)
        {
            _tasks.Add(task);
        }

        public List<Task> GetTasks()
        {
            var tasksToReturn = new List<Task>();

            foreach (var task in _tasks)
            {
                tasksToReturn.Add(new Task
                {
                    Id = task.Id,
                    Description = task.Description,
                    ClientName = task.ClientName
                });
            }

            return tasksToReturn;
        }

        public void SwapTasks(Task task1, Task task2)
        {
            int index1 = _tasks.IndexOf(task1);
            int index2 = _tasks.IndexOf(task2);

            Task replacedTaskStore = _tasks[index1];
            _tasks[index1] = _tasks[index2];
            _tasks[index2] = replacedTaskStore;
        }
    }
}
