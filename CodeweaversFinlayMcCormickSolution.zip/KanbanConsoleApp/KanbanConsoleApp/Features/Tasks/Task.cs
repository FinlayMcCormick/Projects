﻿using System;

namespace KanbanConsoleApp.Features.Tasks
{
    public class Task : IEquatable<Task>
    {
        public string Id { get; set; }
        public string Description { get; set; }
        public string ClientName { get; set; }

        public bool Equals(Task compareTask)
        {
            return Id.Equals(compareTask.Id);
        }
    }
}
