﻿using System;

namespace KanbanConsoleApp.Features.Clients
{
    public class Client : IComparable, IEquatable<Client>
    {
        public string Name { get; set; }

        public int CompareTo(object obj)
        {
            Client compareClient = obj as Client;
            return String.Compare(Name, compareClient.Name);
        }

        public bool Equals(Client compareClient)
        {
            return Name.Equals(compareClient.Name);
        }
    }
}