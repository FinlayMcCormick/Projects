﻿using System.Collections.Generic;
using KanbanConsoleApp.Features.Clients;
using KanbanConsoleApp.Features.Tasks;
using System;

namespace KanbanConsoleApp
{
    public class TaskEngine
    {
        private readonly TaskRepository _taskRepository = new TaskRepository();

        private readonly ClientRepository _clientRepository = new ClientRepository();

        public void SaveTask(Task task)
        {

            if (task.ClientName != null)
            {
                var allClients = _clientRepository.GetClients();

                if (!allClients.Contains(new Client { Name = task.ClientName }))
                {
                    throw new Exception("The supplied Client could not be found.");
                }
            }

            _taskRepository.SaveTask(task);
        }

        public Task RetrieveTaskById(string id)
        {
            var allTasks = _taskRepository.GetTasks();
            foreach (var task in allTasks)
            {
                if (task.Id.Equals(id))
                {
                    return task;
                }
            }

            return null;
        }

        public void SaveClient(Client client)
        {
            _clientRepository.SaveClient(client);
        }

        public List<Client> GetClients()
        {
            return _clientRepository.GetClients();
        }

        public void RemoveClientByName(string name)
        {
            var allClients = _clientRepository.GetClients();

            foreach (var client in allClients)
            {
                if(client.Name.Equals(name))
                {
                    _clientRepository.RemoveClient(client);
                }
            }    
        }

        public List<Task> GetTasksForClient(string clientName)
        {
            var allTasks = _taskRepository.GetTasks();
            var clientTasks = new List<Task>();

            foreach (var task in allTasks)
            {
                if (task.ClientName.Equals(clientName))
                {
                    clientTasks.Add(task);
                }
            }

            return clientTasks;
        }

        public void SwapTasksById(string id1, string id2)
        {
            var allTasks = _taskRepository.GetTasks();
            var task1 = new Task { Id = id1 };
            var task2 = new Task { Id = id2 };

            if (allTasks.Contains(task1) && allTasks.Contains(task2))
            {
                _taskRepository.SwapTasks(task1, task2);
            }
        }
    }
}