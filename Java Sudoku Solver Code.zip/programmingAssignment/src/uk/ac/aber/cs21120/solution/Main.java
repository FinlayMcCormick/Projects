package uk.ac.aber.cs21120.solution;

import uk.ac.aber.cs21120.interfaces.ISolver;
import uk.ac.aber.cs21120.tests.Examples;

public class Main {
    public static void main(String[] args) {
        int gapCount;
        long startTime;
        long timeTaken;
        for(int i = 0; i < 402; i ++) {
            gapCount = Examples.getGapCount(i);
            ISolver solver = new Solver(Examples.getExample(i));
            startTime = System.currentTimeMillis();
            solver.solve();
            timeTaken = System.currentTimeMillis() - startTime;
            System.out.println("Puzzle " + (i + 1) + " with " + gapCount + " gaps took " + timeTaken + "ms to complete\n");
        }
    }
}