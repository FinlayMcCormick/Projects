package uk.ac.aber.cs21120.solution;

import uk.ac.aber.cs21120.interfaces.IGrid;
import uk.ac.aber.cs21120.interfaces.ISolver;
import uk.ac.aber.cs21120.tests.Examples;

public class Main {
    public static void main(String[] args) {
        IGrid grid1 = new Grid();
        grid1.set(1,0,1);
        grid1.set(3,0,6);
        grid1.set(0,1,4);
        grid1.set(4,1,2);
        grid1.set(5,1,1);
        grid1.set(8,1,9);
        grid1.set(7,2,5);
        grid1.set(0,3,7);
        grid1.set(8,3,3);
        grid1.set(1,4,3);
        grid1.set(5,4,8);
        grid1.set(6,4,9);
        grid1.set(7,4,6);
        grid1.set(1,5,8);
        grid1.set(4,5,9);
        grid1.set(5,5,3);
        grid1.set(8,5,2);
        grid1.set(4,6,3);
        grid1.set(8,6,7);
        grid1.set(2,7,1);
        grid1.set(4,7,4);
        grid1.set(7,7,8);
        grid1.set(1,8,5);
        grid1.set(3,8,2);
        grid1.set(5,8,6);
        grid1.set(6,8,3);
        grid1.set(8,8,4);
        System.out.println(grid1.toString());
        ISolver solver1 = new Solver(grid1);
        solver1.solve();
        System.out.println(solver1.toString());

        IGrid grid2 = new Grid();
        grid2.set(0,0,6);
        grid2.set(8,0,9);
        grid2.set(2,1,8);
        grid2.set(4,1,1);
        grid2.set(6,1,7);
        grid2.set(1,2,9);
        grid2.set(4,2,7);
        grid2.set(7,2,6);
        grid2.set(4,3,9);
        grid2.set(0,4,1);
        grid2.set(1,4,7);
        grid2.set(3,4,8);
        grid2.set(5,4,6);
        grid2.set(7,4,5);
        grid2.set(8,4,4);
        grid2.set(2,5,3);
        grid2.set(3,5,7);
        grid2.set(5,5,4);
        grid2.set(6,5,6);
        grid2.set(1,6,3);
        grid2.set(7,6,1);
        grid2.set(1,7,2);
        grid2.set(2,7,1);
        grid2.set(4,7,6);
        grid2.set(6,7,8);
        grid2.set(7,7,7);
        grid2.set(1,8,8);
        grid2.set(7,8,2);
        System.out.println(grid2.toString());
        ISolver solver2 = new Solver(grid2);
        solver2.solve();
        System.out.println(solver2.toString());
    }
}