package uk.ac.aber.cs21120.solution;

import uk.ac.aber.cs21120.interfaces.IGrid;

public class Grid implements IGrid {
    private int[][] sudokuGrid;

    /**
     * constructor that initialises sudokuGrid
     */
    public Grid() {
        sudokuGrid = new int[9][9];
    }

    /**
     * returns value in one cell specified by given coordinates between (0,0) and (8,8)
     * @param x column number
     * @param y row number
     * @return value in cell
     * @throws BadCellException when invalid coordinates given
     */
    @Override
    public int get(int x, int y) throws BadCellException {
        int gridValue;
        //checks coordinates are valid
        if(0 <= x && x <= 8 && 0 <= y && y <= 8) {
            gridValue = sudokuGrid[x][y];
        }
        else {
            throw new BadCellException(x, y);
        }
        return gridValue;
    }

    /**
     * sets value in one cell specified by given coordinates between (0,0) and (8,8)
     * @param x column number
     * @param y row number
     * @param val digit from 1-9, or 0 for an empty cell
     * @throws BadCellException when invalid coordinates given
     * @throws BadDigitException when invalid value given
     */
    @Override
    public void set(int x, int y, int val) throws BadCellException, BadDigitException {
        //checks coordinates are valid
        if(0 <= x && x <= 8 && 0 <= y && y <= 8) {
            //checks value is valid
            if(0 <= val && val <= 9) {
                sudokuGrid[x][y] = val;
            }
            else {
                throw new BadDigitException(val);
            }
        }
        else {
            throw new BadCellException(x, y);
        }
    }

    /**
     * goes over grid to make sure that it is valid according to the rules of sudoku
     * @return if grid is valid
     */
    @Override
    public boolean isValid() {
        //checks that columns and rows are valid
        for(int i = 0; i < 9; i ++) {
            if(!isColumnAndRowValid(i)) {
                return false;
            }
        }
        //checks that sub grids are valid
        //for loops increment by 3 so each sub grid only checked once
        for(int x = 0; x < 7; x += 3) {
            for(int y = 0; y < 7; y += 3) {
                if(!isSubGridValid(x, y)) {
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * checks that column and row are valid for given coordinate
     * @param coord column and row number
     * @return if column and row is valid
     * @throws BadCellException when invalid coordinate given
     */
    private boolean isColumnAndRowValid(int coord) throws BadCellException {
        //checks that coordinate is valid
        if(0 <= coord && coord <=8) {
            int currentValue;
            //loops twice, checking if column is valid first then if row valid
            for(int i = 0; i < 2; i ++) {
                //array representing numbers from 1-9, value set to true if number found
                boolean[] foundNumbers = {false, false, false, false, false, false, false, false, false};
                for (int j = 0; j < 9; j++) {
                    //changes how currentValue set, depends on whether method in first or second loop
                    if(i == 0) {
                        currentValue = sudokuGrid[coord][j];
                    }
                    else {
                        currentValue = sudokuGrid[j][coord];
                    }
                    //if currentValue is a non zero value that has already been found returns false, otherwise updates foundNumbers
                    if (currentValue != 0) {
                        if (foundNumbers[currentValue - 1]) {
                            return false;
                        } else {
                            foundNumbers[currentValue - 1] = true;
                        }
                    }
                }
            }
        }
        else {
            throw new BadCellException(coord, coord);
        }
        return true;
    }

    /**
     * checks that sub grid is valid for given coordinates
     * @param x column number
     * @param y row number
     * @return if sub grid is valid
     * @throws BadCellException when invalid coordinates given
     */
    private boolean isSubGridValid(int x, int y) throws BadCellException {
        //checks that coordinates are valid
        if(0 <= x && x <= 8 && 0 <= y && y <= 8) {
            //array representing numbers from 1-9, value set to true if number found
            boolean[] foundNumbers = {false, false, false, false, false, false, false, false, false};
            int currentValue;
            //normalises x and y values to be top left of sub grid
            x = x - x % 3;
            y = y - y % 3;
            //nested loop to go through every cell in sub grid
            for (int i = x; i < x + 3; i++) {
                for (int j = y; j < y + 3; j++) {
                    currentValue = sudokuGrid[i][j];
                    //if currentValue is a non zero value that has already been found returns false, otherwise updates foundNumbers
                    if (currentValue != 0) {
                        if (foundNumbers[currentValue - 1]) {
                            return false;
                        } else {
                            foundNumbers[currentValue - 1] = true;
                        }
                    }
                }
            }
        }
        else {
            throw new BadCellException(x, y);
        }
        return true;
    }

    /**
     * formats and returns a string as a 9 by 9 grid of numbers representing the current state of sudokuGrid
     * @return string representing grid
     */
    @Override
    public String toString() {
        StringBuilder returnString = new StringBuilder();
        for(int x = 0; x < 9; x ++) {
            for(int y = 0; y < 9; y ++) {
                returnString.append(get(x, y));
            }
            returnString.append("\n");
        }
        return returnString.toString();
    }
}