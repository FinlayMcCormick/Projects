package uk.ac.aber.cs21120.solution;

import uk.ac.aber.cs21120.interfaces.IGrid;
import uk.ac.aber.cs21120.interfaces.ISolver;

public class Solver implements ISolver {
    private Grid sudokuGrid;

    /**
     * constructor that initialises sudokuGrid
     * @param g an IGrid object
     */
    public Solver(IGrid g) {
        sudokuGrid = (Grid) g;
    }

    /**
     * recursive method that will solve any possible sudoku puzzle
     * @return true if puzzle solved, false if not
     */
    @Override
    public boolean solve() {
        //double loop to go through every cell in grid
        for(int y = 0; y < 9; y ++) {
            for(int x = 0; x < 9; x ++) {
                //if cell contains 0, attempts to set it to numbers from 0-9
                if(sudokuGrid.get(x, y) == 0) {
                    for(int i = 1; i <= 9; i ++) {
                        sudokuGrid.set(x, y, i);
                        //if grid is valid recursively calls itself
                        if(sudokuGrid.isValid()) {
                            //if result is true then base case has been reached
                            if(solve()) {
                                return true;
                            }
                        }
                    }
                    sudokuGrid.set(x, y, 0);
                    return false;
                }
            }
        }
        //base case
        return true;
    }

    /**
     * returns a string as a 9 by 9 grid of numbers representing the current state of sudokuGrid
     * @return string representing grid
     */
    @Override
    public String toString() {
        return sudokuGrid.toString();
    }
}